<?php
//used for redirection
ob_start();
//make it available in all our application
session_start();



include("db.php");
include("functions.php")


?>