
<?php

/***** helper functions *************/

//clean anything wrong with input like #$@$%
function clean($string){
    
    return htmlentities($string);
}

function redirect($location){


return header("Location: {$location}");

}

// to not lose the value when going to another page or redirecting like "password updated", instead of echoing, and to see it anywhere in the site

function set_message($message){
    
    
    if(!empty($message)){
        
        //save it in session
        $_SESSION['message']=$message;
        
        
    }else{
        
        
        $message="";
    }
        
    
}


function display_message(){
    
    if(isset($_SESSION['message'])){
        
        
        
        echo $_SESSION['message'];
        
        // so it doesnt stay there all the time.
        unset($_SESSION['message']);
    }
    
    
    
}

//to make forms secure,encrypted string

function token_generator(){
    
    //it will produce unique id,and mt_rand()will provide random values,and md5 will encrypt all this and "true" make it longer and more secure with a prefix
  $token =$_SESSION['token']= md5(uniqid(mt_rand(), true));  
    
    return $token ;
    
    
}

function validation_errors($error_message){
    // we use delimeter so that double or single '' "" wont matter
  $error_message= <<<DELIMITER
         
  <div class="alert alert-danger alert-dismissible" role="alert">
      <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Warning!</strong> $error_message </div>
               
DELIMITER;
               
    return $error_message;        
}


function email_exists($email){
    
    $sql = "SELECT org_id FROM organization_register WHERE org_email = '$email'";
    // calling function query from db.php
    $result = query($sql);
    // row_count() we created in db.php to count how many rows are coming back
    if(row_count($result) == 1){
        
     return true;   
        
        
    }else{
        
      return false;  
        
    }
    
    
    
}

function username_exists($org_name){
    
    $sql = "SELECT org_id FROM organization_register WHERE org_name = '$org_name'";
    // calling function query from db.php
    $result = query($sql);
    // row_count() we created in db.php to count how many rows are coming back
    if(row_count($result) == 1){
        
     return true;   
          
    }else{
        
      return false;  
        
    }
    
    
    
}



function send_email($org_email, $subject, $msg, $headers){


return mail($org_email, $subject, $msg, $headers);


}

/***** validation functions *************/

function validate_user_registration(){
    $errors=[];
    $min=3;
    $max=50;
    $post_max=12;
    $post_min=5;
    
   if($_SERVER['REQUEST_METHOD'] == "POST") {
       
      $org_name        = clean($_POST['org_name']);
      $org_email       = clean($_POST['org_email']);
      $org_address     = clean($_POST['org_address']);
      $postcode        = clean($_POST['postcode']);
      $password        = clean($_POST['password']);
      $confirmpass     = clean($_POST['confirmpass']);
      //strlen to check how many characters
       if(strlen($org_name) < $min){
            
           $errors[] = "Your name cannot be less then {$min} characters";  
       }
       
        
       if(strlen($org_address) < $min){
            
           $errors[] = "Your address cannot be less then {$min} characters";  
       }
       
       
       if(strlen($postcode) < $post_min){
            
           $errors[] = "Your postcode cannot be less then {$post_min} characters or numbers";  
       }
       
       
       if(strlen($postcode) > $post_max){
            
           $errors[] = "Your postcode cannot be more then {$post_max} characters or numbers";  
       }
       
       
       if(strlen($org_name) > $max){
            
           $errors[] = "Your name cannot be more then {$max} characters";  
       }
       
       if(strlen($org_address) > $max){
            
           $errors[] = "Your address cannot be more then {$max} characters";  
       }
       
       if($password !== $confirmpass){
           
            $errors[] = "Your password fields do not match";
           
       }
       
       
       if(email_exists($org_email)){
           
           
            $errors[] = "Sorry that email already registered";
  
           
           
       }
       
       if(username_exists($org_name)){
           
           
            $errors[] = "Sorry that name already taken";
     
           
       }
       
       if(!empty($errors)){
           
           foreach($errors as $error){
                       
           //error display
               
               echo validation_errors($error); 
           }     
       
    } else {


      if(organization_register($org_name,$org_email,$org_address,$postcode,$password,$confirmpass)) {



        set_message("<p class='bg-success text-center'>Please check your email or spam folder for activation link</p>");

        redirect("index.php");


      } else {


        set_message("<p class='bg-danger text-center'>Sorry we could not register the user</p>");

        redirect("index.php");

      }



    }



  } // post request 



} // function 




/****************Register user functions ********************/

function organization_register($org_name,$org_email,$org_address,$postcode,$password,$confirmpass) {


  $org_name      = escape($org_name);
  $org_email     = escape($org_email);
  $org_address   = escape($org_address);
  $postcode      = escape($postcode);
  $password      = escape($password);
  $confirmpass   = escape($confirmpass);



  if(email_exists($org_email)) {


    return false;


  } else if (username_exists($org_name)) {

    return false;

  } else {

    $password   = md5($password);

    $validation_code = md5($org_name + microtime());

   $sql = "INSERT INTO organization_register ( org_name, org_email, org_address, postcode, password,confirmpass)";
     $sql.= "VALUES ('$org_name','$org_email','$org_address','$postcode','$password','$confirmpass')";
    $result = query($sql);
    confirm($result);


    $subject = "Activate Account";
    $msg = " Please click the link below to activate your Account
    http://edwincodecollege.com/login_app/activate.php?org_email=$org_email&code=$validation_code
    ";

    $headers = "From: nono72n@gmail.com";



    send_email($org_email, $subject, $msg, $headers);


    return true;

  }



} 





       
    //pull out values
       
    //another one to use

   /*    $sql = "INSERT INTO organization_register ( org_name, org_email, org_address, postcode, password,confirmpass)
    VALUES ('$org_name','$org_email','$org_address','$'postcode','$password','$confirmpass')";
    if(mysqli_query($connection, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

       if(isset($_POST['register-submit'])){

    $sql = "INSERT INTO organization_register ( org_name, org_email, org_address, postcode, password,confirmpass)
    VALUES ('".$_POST["org_name"]."',
    '".$_POST["org_email"]."','".$_POST["org_address"]."','".$_POST["postcode"]."','".$_POST["password"]."','".$_POST["confirmpass"]."')";

    $result = query($sql);

    echo $result ;

}  
     //  echo "it works" ;
        }
   
    }
   
    
    /* 
    if(mysqli_query($connection, $query)){
        echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $query. " . mysqli_error($connection);

}
    */





?>